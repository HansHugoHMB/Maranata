import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // No API routes needed for this application as all data is client-side
  // This is a simple static web application

  const httpServer = createServer(app);

  return httpServer;
}
