import { useState, useEffect, useMemo } from "react";
import { Hymn } from "./HymnalApp";
import { Input } from "@/components/ui/input";

interface SidebarProps {
  hymns: Hymn[];
  searchTerm: string;
  onSearchChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  selectedHymn: Hymn | null;
  onSelectHymn: (hymn: Hymn) => void;
}

export default function Sidebar({
  hymns,
  searchTerm,
  onSearchChange,
  selectedHymn,
  onSelectHymn,
}: SidebarProps) {
  const [groupedHymns, setGroupedHymns] = useState<Record<string, Hymn[]>>({});
  const [expandedLetters, setExpandedLetters] = useState<Set<string>>(new Set());

  // Group hymns by first letter
  useEffect(() => {
    const grouped: Record<string, Hymn[]> = {};
    
    hymns.forEach(hymn => {
      // Get the first letter of the title (after the number)
      const match = hymn.title.match(/^\w+\.\s+([A-Z])/);
      const firstLetter = match ? match[1] : hymn.title.charAt(0);
      
      if (!grouped[firstLetter]) {
        grouped[firstLetter] = [];
      }
      grouped[firstLetter].push(hymn);
    });
    
    setGroupedHymns(grouped);
    
    // Initially expand the section containing the selected hymn
    if (selectedHymn) {
      const match = selectedHymn.title.match(/^\w+\.\s+([A-Z])/);
      const letter = match ? match[1] : selectedHymn.title.charAt(0);
      setExpandedLetters(prev => new Set(prev).add(letter));
    }
  }, [hymns, selectedHymn]);

  // Filter hymns based on search term
  const filteredHymns = useMemo(() => {
    if (!searchTerm.trim()) return groupedHymns;

    const filtered: Record<string, Hymn[]> = {};
    const term = searchTerm.trim().toLowerCase();

    Object.entries(groupedHymns).forEach(([letter, letterHymns]) => {
      const matchingHymns = letterHymns.filter(hymn => 
        hymn.title.toLowerCase().includes(term) || 
        hymn.number.toString().includes(term) ||
        hymn.lyrics.toLowerCase().includes(term)
      );
      
      if (matchingHymns.length > 0) {
        filtered[letter] = matchingHymns;
        // Expand sections with matches
        setExpandedLetters(prev => new Set(prev).add(letter));
      }
    });

    return filtered;
  }, [groupedHymns, searchTerm]);

  const toggleLetter = (letter: string) => {
    setExpandedLetters(prev => {
      const newSet = new Set(prev);
      if (newSet.has(letter)) {
        newSet.delete(letter);
      } else {
        newSet.add(letter);
      }
      return newSet;
    });
  };

  // Get available letters for alphabet navigation
  const availableLetters = Object.keys(groupedHymns).sort();

  return (
    <aside className="bg-secondary w-full md:w-1/3 lg:w-1/4 p-4 overflow-y-auto h-[30vh] md:h-auto" id="sidebar">
      <div className="mb-4">
        <label htmlFor="search" className="block mb-2 font-medium">
          Rechercher un cantique:
        </label>
        <Input
          id="search"
          value={searchTerm}
          onChange={onSearchChange}
          className="w-full px-3 py-2 bg-primary border border-accent rounded"
          placeholder="Titre ou numéro..."
        />
      </div>
      
      <div className="alphabet-divider py-2 border-b border-accent mb-4">
        <div className="flex flex-wrap gap-1">
          {availableLetters.map((letter) => (
            <button
              key={letter}
              onClick={() => {
                toggleLetter(letter);
                document.getElementById(letter)?.scrollIntoView({ 
                  behavior: "smooth",
                  block: "start" 
                });
              }}
              className="px-2 py-1 bg-primary hover:bg-accent rounded text-sm font-medium"
            >
              {letter}
            </button>
          ))}
        </div>
      </div>
      
      <div id="hymn-index" className="space-y-2">
        {Object.keys(filteredHymns).sort().map((letter) => (
          <details
            key={letter}
            id={letter}
            className="bg-primary rounded"
            open={expandedLetters.has(letter)}
          >
            <summary 
              className="font-serif font-semibold p-2 cursor-pointer hover:bg-highlight"
              onClick={(e) => {
                e.preventDefault();
                toggleLetter(letter);
              }}
            >
              {letter}
            </summary>
            <ul className="p-2 space-y-1">
              {filteredHymns[letter].length > 0 ? (
                filteredHymns[letter].map((hymn) => (
                  <li
                    key={hymn.id}
                    className={`hymn-title ${selectedHymn?.id === hymn.id ? 'selected bg-highlight' : ''}`}
                    onClick={() => onSelectHymn(hymn)}
                  >
                    N° {hymn.number}. {hymn.title}
                  </li>
                ))
              ) : (
                <li className="text-gray-400 italic p-1">Aucun cantique</li>
              )}
            </ul>
          </details>
        ))}
      </div>
    </aside>
  );
}
