import { Hymn } from "./HymnalApp";
import { Card, CardContent } from "@/components/ui/card";

interface HymnContentProps {
  hymn: Hymn | null;
}

export default function HymnContent({ hymn }: HymnContentProps) {
  return (
    <section className="flex-1 p-4 md:p-6 overflow-y-auto" id="hymn-content-container">
      <div className="max-w-3xl mx-auto">
        {hymn ? (
          <Card className="bg-secondary shadow-lg">
            <CardContent className="p-6">
              <header className="mb-4 border-b border-accent pb-2">
                <h2 className="text-xl font-serif font-semibold" id="hymn-title">
                  N° {hymn.number}. {hymn.title}
                </h2>
                {hymn.key && (
                  <p className="text-sm text-gray-300" id="hymn-key">
                    {hymn.key}
                  </p>
                )}
              </header>
              
              <div className="hymn-content leading-relaxed" id="hymn-lyrics">
                {hymn.lyrics}
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="bg-secondary shadow-lg">
            <CardContent className="p-6 text-center">
              <p>Sélectionnez un cantique dans la liste.</p>
            </CardContent>
          </Card>
        )}
      </div>
    </section>
  );
}
