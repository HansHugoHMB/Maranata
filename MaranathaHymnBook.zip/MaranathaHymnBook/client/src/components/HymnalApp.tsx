import { useState, useEffect } from "react";
import Sidebar from "./Sidebar";
import HymnContent from "./HymnContent";
import { hymns } from "../lib/hymnData";
import { useToast } from "@/hooks/use-toast";

export type Hymn = {
  id: number;
  number: number;
  title: string;
  key?: string;
  lyrics: string;
};

export default function HymnalApp() {
  const [selectedHymn, setSelectedHymn] = useState<Hymn | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    // Load the first hymn on initial render
    if (hymns.length > 0 && !selectedHymn) {
      setSelectedHymn(hymns[0]);
    }
  }, []);

  useEffect(() => {
    // Show a toast when the data is loaded
    if (hymns.length > 0 && !selectedHymn) {
      toast({
        title: "Cantiques chargés",
        description: `${hymns.length} cantiques sont disponibles.`,
      });
    }
  }, [hymns, selectedHymn, toast]);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleHymnSelect = (hymn: Hymn) => {
    setSelectedHymn(hymn);
    
    // On mobile, scroll to the content section
    if (window.innerWidth < 768) {
      document.getElementById("hymn-content-container")?.scrollIntoView({ 
        behavior: "smooth" 
      });
    }
  };

  return (
    <main className="flex flex-col md:flex-row flex-1 overflow-hidden">
      <Sidebar 
        hymns={hymns}
        searchTerm={searchTerm}
        onSearchChange={handleSearchChange}
        selectedHymn={selectedHymn}
        onSelectHymn={handleHymnSelect}
      />
      <HymnContent hymn={selectedHymn} />
    </main>
  );
}
