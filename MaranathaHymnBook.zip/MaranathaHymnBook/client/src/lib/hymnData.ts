export const hymns = [
  {
    id: 1,
    number: 1,
    title: "NDI MUMANYATSHIDI MASHI",
    key: "Ab",
    lyrics: `Ndi mumanya tshidi mashi
Ndi mumanya tshidi mashi buanyi
Pamvua mujimine
Yesu wakankeba
Mashi adi moyo buanyi.

Mashi a Yesu
Mashi a Nzambi ndupandu
Mibi yanyi yonso
Yakajimijibua
Mashi adi moyo buanyi.

Bu Yesu kayi mulue
Bu Yesu kayi mulue pa buloba
Nakadi kujimine
Mu malu mabi anyi
Mashi adi moyo buanyi.

Dinanga dya Nzambi
Dinanga dya Nzambi kundi
Pamvua muntu mubi
Yesu wakamfuila
Mashi adi moyo buanyi.

Ndi nsanka bua Yesu
Ndi nsanka bua Yesu wanyi
Ndi nsanka bua Yesu
Musungidi wanyi
Mashi adi moyo buanyi.

Ndi ngimba bua Yesu
Ndi ngimba bua Yesu wanyi
Ndi ngimba bua Yesu
Musungidi wanyi
Mashi adi moyo buanyi.

Bua luse lua Yesu
Bua luse lua Yesu kundi
Pamvua mu dikenga
Wakalua kunsamba
Mashi adi moyo buanyi.`
  },
  {
    id: 2,
    number: 2,
    title: "KATUENA NE MULUNDA BU YESU",
    key: "G",
    lyrics: `Katuena ne mulunda bu Yesu
Kenaku, kenaku
Katuena ne mulunda bu yeye
Kenaku kenaku.

Kolus

Yesu mmumanye malu etu
Yeye udi mulombodi
Katuena ne mulunda bu Yesu
Kenaku, kenaku.

Katuena ne mulunda muakane
Bu Yesu, bu Yesu
Kakuena muntu mudipuekesha
Bu Yesu, bu Yesu.

Yeye kena utushiya nansha
O nansha, o nansha
Mu butuku kena utushiya
O nansha, o nansha.

Kena upidia muntu muakane,
O nansha, o nansha
Kena upidia muntu mubi to
O nansha, o nansha.

Kakuena dipa dimpe bu Yesu
Kadienaku nansha
Kakuena Dina dimpe bu Yesu
Kadienaku nansha.`
  },
  {
    id: 3,
    number: 3,
    title: "PANGELA MEJI",
    key: "G",
    lyrics: `Pangela meji ne mbalulula
Bualu ne bualu buebe Yesu
Moyo wanyi udi usanka be
Bualu wakalua kunsungila.

Kolus

Bua meme eu muntu patupu
Mupetudibue kudi bonso
Mvua ne mushinga ku mesu kuebe
Kuakasanka bua lufu luanyi

Njiu ya lufu yakalua kundi
Imvua tshiyi mua kupanduka
Wewe kuakasua bua meme kufua
Wakadifila muaba wanyi.

Wewe Mukelenge wa butumbi
Bakakukudika ku mutshi
Wakavudibua bilamba biebe
Wakakenga pa muaba wanyi.

Dituku-adi ndya bualu bukole
Midima ivua pa buloba
Bufuki bonso buakabungama
Bua lufu lua Mufuki wabo.

Minda ya mulu kayakatema
Yakabenga ne nsesa yayo
Bua kutangila Mufuki wayo
Yoyo yakakuatshika bundu.

Muena kulumbulula kuakane
Nzuji Munene nguewe Yesu
Pawakapisha bufuki bonso
Wakadivuija Mutuakuidi.`
  },
  {
    id: 4,
    number: 4,
    title: "TSHILOBO",
    key: "D",
    lyrics: `Mumanyi munene wa mvita
Mutshimunyi wa kalekale
Tshilobo tshikole mu mvita
Yesu ukena kutshimuna.

Kolus

Tshilobo we ! juka wenda
Madiunda mu baluishi bebe
Bana bebe babandila
Luendu luebe lua butshimunyi.

Misumba yonso ya mu diulu
Idi panyima pebe wewe
Bua kutumbisha Dina diebe
Mumanyi munene wa mvita

Diboko diebe dya bukole
Didi dibandishibue kulu
Pa mutu pa makola onso
Ne mamanya onso a mvita

Wewe Mukemeshi wa bantu
Bua dimanya dyebe dya mvita
Ne mishindu ya ditshimuna
Nganyi wapalakana n'ebe.

Dituku dikadi pabuipi
Diwabutula bantu babi
Ne muambi wabo wa mashimi
Popamue ne nyama wa lonji.`
  },
  {
    id: 5,
    number: 5,
    title: "MUIMPE MUIMPE",
    key: "G",
    lyrics: `Muimpe muimpe nguewe Yesu,
Udi muimpe tshishiki
Malu ebe onso adi
Mimpe matuku onso
Utu waleja dinanga dyebe
Kudi bufuki bonso

Bua ba mu bikondo ne bikondo
Bamone buimpe buebe.

Kuena ne kansungansunga
Kudi ba pa buloba
Bua utu watemeshila
Bimpe ne babi munya
Utu walokesha mvula yebe
Kudi bimpe ne babi
Udi mubinga mu bienzedi byebe
Nzambi muena dinanga.

Pakajimina bufuki
Wewe kuakasanka to
Wakafila diandamuna
Dya nshinga wa lupandu
Bua kusungila bufuki bonso
Buakadi bujimine
Kuakasua bua kutuma banjelo
Wewe wakadivuila.

Oh lubila luakedibua
Ku nkuasa wa butumbi
"Nganyi udi ne buakane
Abulula mukanda ?"
Mu diulu ne pa buloba mene
Ne muinshi mua buloba
Kakuakadi uvua ne buakane
Anu Muan'a mukoko.

Nyama ne nyunyi isanke
Bua bupikudi ebu
Mitshi ituta bikashi
Itumbisha Mufuki
Mayi manene atuta tshiona
Bua butumbi bua Yesu
Mikuna ne bibanda ne mpongo
Bitumbisha Kilisto.

Bana betu banangibue
Nusanke pamue nanyi
Bualu bua lupandu elu
Ndufidibue tshianana
Pandi ne moyo mbua muntu eu
Udibo bamba Yesu
Bua bualu buende ndi ngenda ntunku
Mu butumbi bua Nzambi.`
  },
  {
    id: 6,
    number: 6,
    title: "NDI NKUTEKEMENA NZAMBI WANYI",
    key: "Eb",
    lyrics: `Pa buloba ndipu
Tshitupa tshikese
Ndi muenyi ne muena
Luendu pa buloba
Dituku dikuabo
Nempingana kuetu
Nenshalaku tshiendelela.

Kolus

Ndi nkutekemena
Wewe Nzambi wanyi
Ndi ngindila bianyi
Dikuatshisha dyebe
Mesu anyi adi
Matangija kûdi
Wewe tshieyemenu tshianyi.

Pandi ngeyemena
Muntu yeye neafue
Pangeyemena dibue
Nedipandike
Pandi ngeyemena
Mutshi neupuke
Ne ngeyemena tshinganyi ?

Pandi nkueyemena
Wewe Nzambi wanyi
Tshiena mfuishibua
Bundu nansha kakese
Mu dituku dibi
Panakubikila
Kuena umbengela nansha.

Nzambi wanyi wewe
Udi bionso kundi
Wewe ke udi ne diyi
Dya ndekelu
Tshiudi wamba ke
tshidi tshienzekibua
Ndi ndifila kudi wewe.`
  },
  {
    id: 7,
    number: 7,
    title: "NDI NE DIBUE DYANYI",
    key: "Ab",
    lyrics: `Ndi ne dibue dyanyi
Dibue dya tshieyemenu
Dibue dyanyi didi
Yesu Kilisto
Pandi ngimana popo
Tshiena nyungishibua to
Yesu Kilisto dibue dikole.

Kolus

Tshiena ntshina kabidi (2x)
Yesu Kilisto udi dibue dyanyi
Dibue dya tshieyemenu (2x)
Tshiena ntshina bualu
Bua ndi ne Yesu.

Mu malu makole
Mu bipupu bikole
Meme tshiena mua
kuzakajibua to
Ndi ngimana pa dibue
Dyanyi dya tshieyemenu
Ndi ngimana ne dikima dionso.

Yesu ndibue dyanyi
Tshisokomenu tshyanyi
Dikuatshisha dyanyi
Mu malu onso
Ndi ngamba ne dikima
Tshiyi mua kukenzakana
Bua kutangila tshintu tshikuabo.

Mu malu onso adi
Alua kundi lubilu
Yesu wanyi udi
Mumanya onso
Bialua bualu butuku
Nansha bulua mu munya
Yesu Kilisto udi mumone.`
  },
  {
    id: 8,
    number: 8,
    title: "MUTAMBA SOLOMO",
    key: "Eb",
    lyrics: `Yesu udi ubikila
Badi ne majitu
Ne badi baditshiokesha
Abape dikisha.

Kolus

Yesu udi dyandamuna
Ku lukonko lonso mene
Kakuena bualu bukole
Kumpala kua Yesu Mfumu

Biwikala ne tshilumbu
Ne bualu mu moyo
Biwenda konso upanga
Ulue kudi Yesu.

Bidi bikolela bantu
Ne bibatatshisha
Kudi Yesu mbipepele
Lua kudiye lelu.

Mutamba Solomo Yesu
Udi dyandamuna
Ku nkonko yonso ya bantu
Idi munda muabo.`
  },
  {
    id: 9,
    number: 9,
    title: "JESUS SOUFFRIT POUR MOI",
    key: "G",
    lyrics: `Jésus était blessé
Pour mes transgressions
Et brisé pour mon iniquité
Voila le châtiment
Qui me donne la paix
Est tombé sur lui pour mon salut.

Choeur

Quand Jésus suivit
Le chemin de la mort
C'était pour moi
C'était pour moi
Pour me délivrer
De mon terrible sort
Jésus souffrit pour moi.

C'est par Ses meurtrissures
Que je suis guéri,
A lui soient la gloire et l'honneur
Vainqueur de Golgotha
Jésus Roi des rois
A lui soit la gloire
Pour toujours.

Il a été maltraité
Et opprimé
Et il n'avait point ouvert la bouche
Comme l'agneau qu'on mène
A la boucherie
Tout cela pour me
Donner la vie.

Là haut sur la croix
Oh ! Jésus a tout fait,
Tout est accompli à Golgotha
Comme l'a dit Jésus
Seul mon Rédempteur
Et je crois à l'œuvre
Du calvaire.`
  },
  {
    id: 10,
    number: 10,
    title: "PANDI NE YESU",
    key: "Ab",
    lyrics: `Tshiena ne diba dya kujimija
Ku malu a pa buloba ebu
Mem'eu ndi muenyi
Ne muena luendu
Mutangila ku musoko wanyi.

Kolus

Pandi ne Yesu
Ndi ne bionso
Ndi nsanka bua kuikala
Pamue n'ende,
Pabuipi n'ende
Diba dionso
Bua kumona
butumbi buende.

Ndi munkatshi mua luendu lukole
Luendu lua kuya ku muaba wanyi
Mu njila mudi ntatu ya bungi
Ndi mutangila
Anu kumpala.

Tshiena ntangila bidi bimueka
Bintu bidi bituta ku mesu
Ndi ngenda bianyi mu ditabuja
Tô ne panamona
Mukelenge.

Panapungila mu njila wanyi
Yesu udi ulua kunkolesha
Panadishinda udi unjula
Udi undama
Bua tshipambuki.`
  },
  {
    id: 11,
    number: 11,
    title: "NDI NKUNANGA YESU KILISTO",
    key: "E",
    lyrics: `Ndi nkunanga Yesu Kilisto
Nzambi wanyi ndi nkunanga
Bua wewe wakadyanjila kundeja
Dinanga dyebe Kale
Oh ! Yesu ndi nkunanga
Aleluya !
Oh ! Yesu ndi nkunanga
Wakadyanjila kunsungula
Oh ! ku tshibangidilu tshya bufuki
Oh ! tuasakidila Nzambi
Aleluya !
Tuasakidila Nzambi.

Meme muena mibi ne dikenga
Wakamvuluka bianyi
Bua mu muaba umvua meme
Mua kufua wakafua bualu buanyi
Tuasakidila Nzambi
Aleluya !
Tuasakidila Nzambi
Bikala muntu muimpe ufua
Bua muenji wa mibi asungidibue
Oh ! dinanga kayi bunene !
Aleluya !
Tuasakidila Nzambi.

Tshiena ne mpata tshyena ne bowa
Yesu wakantshimuina
Wakela lubila kulu kua mutshi
Ne « bionso biakumbanyi »
Mudimu wakajika
Aleluya!
Mudimu wakajika
Ku mibundabunda ya Yesu
Ke kunakapetela diondopibua
Oh! mudimu wakajika
Aleluya!
Tuasakidila Nzambi
Aleluya!
Mudimu wakajika
Aleluya!
Tuasakidila Nzambi
Aleluya!
Dinanga kayi bunene
Aleluya!
Tuasakidila Nzambi.`
  },
  {
    id: 12,
    number: 12,
    title: "MALU A KALE A KUMANA KUSHALA",
    key: "G",
    lyrics: `Nakujimija bintu bianyi
Bua wewe Yesu
Bionso bimvua mbala bu
Bintu bya mushinga be
Nakuela ku diyala
Bua kukupeta wewe
Nakuitabuja bundu
Ne bipendu bua wewe

Kolus

Malu a kale
Akumana kushala
Ndi nkulonda Yesu
Tô ne kunshikidilu.

Nenye kunyi kukuabu
Kudi nganyi mukuabu
Wewe ngudi ne meyi a
moyo wa tshiendelela
Kumpala kuanyi tshiena
Mumanya mukuabo to
Ndi mukumanya anu
Wewe Yesu Kilisto

Dipangadika dyanyi
Ndya kukulonda wewe
Ngenda mpona ne mbika
Mutangila kumpala
Tshiena ngitabuja bua
Makasa anyi meme
Apingana panyima
Tô ne ku dibutuka.

Ndi mushikila konso
Tshiena ne kua kuya to
Bia pa buloba bionso
Biakumana kuntonda
Nakusungula njila
Udi mutamba yonso
Munda mua diyi dyebe`
  },
  {
    id: 13,
    number: 13,
    title: "BIONSO MBISHIPILA",
    key: "G",
    lyrics: `Bionso mbishipila bionso
Bia panshi aa
Kakuena tshintu nansha tshimue
Tshidi ne mushinga
Mesu anyi kena amona
Bisanka bia panshi aa
Bidi anu mena a Yesu
Andi mpunga.

Wewe nzambi
Mulundebue
Mpungu tshiadi
Tshiena nansha
Mbingu mu bionso
Kabiena bikampasha
Malu a panshi aa
Twasu tundambule.

Kubuela kua bimpe
Nanku luba ne tshidi tshikole
Tshiena nya tshitshima tshikole
Tshiena mutonde
Mpala ebe Yesu
Mmu butumbi
Wa mona buimpe
Bua kuamba tshiena.`
  },
  {
    id: 14,
    number: 14,
    title: "BUALU BANYI YESU WAKENZA",
    key: "Eb",
    lyrics: `Bualu banyi Yesu wakenza
Tshiakufua netu.
Lufu luimpe lua Yesu
Ndidi mubuela mu moyo.

Kolus

Aleluya ngikala ne Yesu
Mona ne wakampikula
Aleluya ngikala ne Yesu
Ndi naya kuikala naye.

Bualu buanyi Yesu wakafua
Tshiena umoyo kabidi
Muoyo mupia-mupia udi
Mu mashi a Yesu Kilisto.

Mulamba watshiba kauyi
Ne disanka dya ku mbelu
Ku moyo kuanyi munda mule
Dijinga dya kumona Yesu.

Muinshi mua kubabala eku
Wakapita mu ditalala
Ku ditalala wakayaye
Kua Tatu wende wa diulu.`
  },
  {
    id: 15,
    number: 15,
    title: "NYUMA WEBE ANYISHE MUKELENGE",
    key: "D",
    lyrics: `Nyuma webe anyishe Mukelenge
Anyishe palua tshisamba
Mapangadika ende kebe
Wisha pa misoko ya bantu.

Kolus

Lukuna luebe ludi lunanga
Bantu badi bajimina
Nyuma webe Anyishe
Ku misoko yonso ya panshi.

Bantu badi mu midima
Kabayi bamanye bukole buebe
Ku mitshima yabo utume
Bukole bua wewe Nyuma.

Nyuma wa Nzambi udi wa meji
Ne bukole bua kusungila
Nyuma wa kuatshisha ne dinanga
Wakapanisha Sathana.

Mu mesu mebe bandejaku
Bantu mudi mushipile
Ku mitshima yetu wakulaku
Bitapidi ne kanyinganyinga.

Mukelenge wakuleshaku
Nyuma webe mu mitshima
Tusambedi bikale bulelele
Ne mu Nyuma ne buakane.`
  },
  {
    id: 16,
    number: 16,
    title: "ALLELUIA",
    key: "G",
    lyrics: `Alléluia ! Alléluia ! Alléluia !
Le Seigneur régna la terre est dans l'allégresse
les îles nombreuses se réjouissent.

Alléluia ! Alléluia ! Alléluia !
Que s'ouvrent les cieux et l'obscurité
Que s'ouvrent les cieux
et la terre tressaille de joie.

Alléluia ! Alléluia ! Alléluia !
Que s'ouvrent les portes des demeures de Dieu
afin que je verrai la face du roi Emmanuel

Alléluia ! Alléluia ! Alléluia !
L'esprit et l'épouse disent : viens
Et que celui qui entends dise viens
Viens Seigneur Jésus.

Alléluia ! Alléluia ! Alléluia ! 
Le désert et la terre aride se réjouiront
Le pays brûlé tressaillira de joie
et fleurira comme un narcisse.

Alléluia ! Alléluia ! Alléluia !
Si tu leur ôte le souffle, ils expirent
et retournent à leur poussière
Tu envoies ton souffle ils sont créés.`
  },
  {
    id: 17,
    number: 17,
    title: "SAINTE CENE",
    key: "G",
    lyrics: `Joignons nos mains pour donner gloire à Dieu
Car il nous a aimés de tout son cœur 
Il nous a tous réunis en Lui-même 
Tout autour de la Table de Jésus. 

Kolus

Oh mon ami vois la grâce qui te donne
Même son Corps brisé pour te sauver
Oh mon ami, vois ce Sang qui te nourrit
Pour te donner la vie et te sauver.

Père, Père, oh ! notre Père
Nous voici autour de la table
Père, Père, oh ! notre Père
Nous sommes venus pour T'honorer.
Alléluia Amen, Alléluia Amen !

Père, Père, oh ! notre Père
Viens, nous T'offrons notre obéissance.
Père, Père, oh! notre Père
L'obéissance, oh c'est pour te plaire
Alléluia Amen, Alléluia Amen !

Vois mon ami, vois ma sœur, vois mon frère 
Vois, nous sommes tous unis dans le Seigneur,
Vois, le Seigneur est au milieu de nous.
Mangeons et buvons en Sa présence.
Alléluia Amen, Alléluia Amen !

Gloire à toi, gloire à toi, et honneur
Gloire, oui, gloire à Toi Seigneur.
Honneur, oui, Honneur à Toi notre Dieu
Car, tu nous as rachetés par ton sang,
Alléluia Amen, Alléluia Amen !`
  },
  {
    id: 18,
    number: 18,
    title: "ENSEMBLE NOUS POUVONS",
    key: "G",
    lyrics: `Ensemble nous pouvons changer le monde,
Ensemble nous pouvons tout accomplir.
Ensemble nous pouvons sauver les âmes
Dans le nom de Jésus nous sommes unis.

Ensemble, ensemble : Alléluia ! (2x)
Dans le nom de Jésus, nous sommes unis (2x)
Alléluia, louons l'Eternel (2x)
Dans le nom de Jésus nous sommes unis.`
  },
  {
    id: 19,
    number: 19,
    title: "BALUA MBUELA",
    key: "D",
    lyrics: `Balua mbuela, balua mbuela
Balua mbuela ku musoko wa Mukelenge.

Kolus

Usuma usuma musoko wa mukelenge.
Usuma usuma batendelai bupuane.

Bantu babi kabenamubuela to
Bantu babi kabenamubuela to.

Bena mambu kabenamubuela to
Bena mambu kabenamubuela to.

Batendelai kabalua mbuela
Batendelai kabalua mbuela.`
  },
  {
    id: 20,
    number: 20,
    title: "TU ES DIGNE",
    key: "D",
    lyrics: `Tu es digne de gloire et d'honneur
Tu es digne ô Jésus ô mon Sauveur (2x)

Pères lèves les mains et adores Jésus
Mères lèves les mains et adores Jésus
Frères lèves les mains et adores Jésus
Sœurs lèves les mains et adores Jésus.
Tous ensemble adorez Jésus Christ.`
  },
  {
    id: 21,
    number: 21,
    title: "WAKAFUA PO MEME",
    key: "G",
    lyrics: `Wakafua po meme
Po meme po meme
Wakafua po meme
Yesu wakafua.

Kolus

Ndi ne disanka 
Disanka dia bungi
Bua yeye udi munfuile
Yesu mupikudi.

Mutshi utoke, mutshi utoke
Mutshi utoke wakamuengbesha.

Paulo wakamba, Paulo wakamba
Paulo wakamba ndi kaba koso.

Diboko dibi, diboko dibi
Diboko dibi wakamuasa to.

Wakabika, wakabika
Wakabika mu bantu bafue.

Yesu walua, yesu walua 
Yesu walua bua kuangata.

Wadi kuluilu, wadi kuluilu
Wadi kuluilu mu butumbe buo.`
  },
  {
    id: 22,
    number: 22,
    title: "TOUT LE MONDE",
    key: "G",
    lyrics: `Tout le monde devrait savoir
Tout le monde devrait savoir
Tout le monde devrait savoir
Qui est Jésus-Christ

C'est l'Alpha et l'Oméga
C'est le puissant Dieu de gloire
C'est le lis de la vallée
L'étoile du matin.

C'est le Seigneur sur tout esprit
Il est le Roi de victoire
Il est le grand j'ai vu
Depuis, je suis libre.

Il est Christ qui a porté
Mes péchés à la croix
Il est l'Agneau du calvaire
Mon Seigneur est le Sauveur.

Il est l'Agneau qui a racheté
Mon péché à la croix
Ma vie n'est plus à moi même
Elle est entièrement à Christ.`
  },
  {
    id: 23,
    number: 23,
    title: "BULOBA BUJIMA",
    key: "Bb",
    lyrics: `Buloba bujima ne butumbi buebe
Buloba bujima ne butumbi buebe
Buloba bujima ne butumbi buebe
Mukelenge mu ntempelu webe.

Kolus

Nunku santu, nunku santu, nunku santu
Nunku santu, nunku santu, nunku santu
Nunku santu, nunku santu, nunku santu
Mukelenge mu ntempelu webe

Njila yebe ne butumbi buebe
Njila yebe ne butumbi buebe
Njila yebe ne butumbi buebe
Mukelenge mu ntempelu webe.`
  },
  // Ajout des cantiques 24-110 ici
  {
    id: 110,
    number: 110,
    title: "YESU MUPIKUDI WANYI",
    key: "G",
    lyrics: `Yesu mupikudi wanyi
Mupikudi wa bonsu
Wasungila ba pa buloba
Ku bibi bia bonsu.

Kolus

Yesu mupikudi wanyi
Ndi ngenda ne wewe
Utangila wa bukokeshi
Wa malu onsu anyi.

Yesu usungila bantu
Ba mitu mikole
Ne ba mitshima ya mpata
Uyitabuja bonsu.

Mutshima webe wa luse
Kabawumanyi
Ku matuku a mu bidimu
Mulaule kabuyi.

Pamona Yesu lumingu
Ntu ne disanka
Lelu ludi lumingu lua
Bena kuitabuja.

Bantu ba mu moyo elu
Badi ne disanka
Mu dituku dia bukokeshi
Nebamone Yesu.`
  }
];
