import HymnalApp from "./components/HymnalApp";
import { Toaster } from "@/components/ui/toaster";

function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-secondary p-4 shadow-md">
        <h1 className="text-2xl font-serif font-semibold text-center">MARANATHA</h1>
        <p className="text-center">Recueil de 110 Cantiques</p>
      </header>

      <HymnalApp />

      <footer className="bg-secondary p-4 text-center text-sm">
        <p>© {new Date().getFullYear()} Recueil de Cantiques MARANATHA</p>
      </footer>
      <Toaster />
    </div>
  );
}

export default App;
